<?php
//Eliminar el archivo que tiene la conexion
include_once 'conexion.php';
//Quien recibe la informacion que desea eliminar
$id_cliente=$_GET['id_cliente'];
//Esto se trabajo en mysql en phpmyadmin
$delete= "DELETE FROM clientes  WHERE id_cliente= '{$id_cliente}' ";
//Ejecutar el codigo de la base de datos
$ejecutar=mysqli_query($conexion, $delete);

$json=array(); //array para trasladar la informacion en formato JSON

$datos["id_cliente"]=$id_cliente;
$datos["nombre"]="datos eliminados";
$datos["apellido"]=0;
$datos["telefono"]="datos eliminados";
$datos["correo"]="datos eliminados";

$json ['clientes'][]=$datos;
echo json_encode($json);
?>

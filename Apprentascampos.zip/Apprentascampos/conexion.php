<?php
$host="localhost";
$usuario="root";
$contraseña="";
$basedatos="alquiler_de_campos";

$conexion=mysqli_connect($host,$usuario,$contraseña,$basedatos);
if (!$conexion){
    echo "Error en conexion en MySQL";
}else{
    echo "Conexion Exitosa";
}
?>
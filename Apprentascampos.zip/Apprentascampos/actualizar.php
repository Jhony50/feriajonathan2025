<?php
//utilizar el archivo que tiene la conexion
include_once 'conexion.php';
$id_cliente=$_GET['id_cliente'];
$nombre =$_GET['nombre'];
$apellido=$_GET['apellido'];
$telefono=$_GET['telefono'];
$correo=$_GET['correo'];

 //SQL para insertar datos;
 $actualizar = "UPDATE clientes SET nombre='{$nombre}', apellido='{$apellido}', telefono='{$telefono}', correo='{$correo}' WHERE id_cliente ='{$id_cliente}'";
 //ejecutar el codigo en la base de datos 

$ejecutar = mysqli_query($conexion, $actualizar);
$json=array(); //array para transladar informacion en formato json
$datos["id_cliente"]=$id_cliente;
$datos["nombre"]=$nombre;
$datos["apellido"]=$apellido;
$datos["telefono"]=$telefono;
$datos["correo"]=$correo;

$json['clientes'][]=$datos;

echo json_encode($json);
?>
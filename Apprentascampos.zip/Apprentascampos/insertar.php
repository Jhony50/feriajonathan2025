<?php
//utiliza el archivo que tiene la conexion
include_once 'conexion.php';
//recibir los datos que deseo insertar
$id_cliente=$_GET['id_cliente'];
$nombre=$_GET['nombre'];
$apellido=$_GET['apellido'];
$telefono=$_GET['telefono'];
$correo=$_GET['correo'];

//SQL para insertar datos
$insertar="INSERT INTO clientes (id_cliente,nombre,apellido,telefono,correo) VALUES('{$id_cliente}','{$nombre}','{$apellido}','{$telefono}','{$correo}')";


$ejecutar=mysqli_query($conexion, $insertar);

$json= array(); //el array traslada la informacion en formato json para la app android

$datos["id_cliente"]=$id_clientes;
$datos["nombre"]=$nombre;
$datos["apellido"]=$apellido;
$datos["telefono"]=$telefono;
$datos["correo"]=$correo;

$json['clientes'][]=$datos;
echo json_encode($json);
?>
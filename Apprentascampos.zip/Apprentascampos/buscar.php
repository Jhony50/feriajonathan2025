<?php
include_once 'conexion.php';
$id_cliente = $_GET['id_cliente'];
$busqueda = "SELECT * FROM clientes WHERE id_cliente= '{$id_cliente}'";
$resultado_busqueda = mysqli_query($conexion, $busqueda);
$json = array();
$contar = 0;
while($datos = mysqli_fetch_array($resultado_busqueda)){
    $json['clientes'][]=$datos;
    $contar = $contar+1;
}
if($contar==0){
    $datos["id_cliente"]=-1;
    $datos["nombre"]="Nombre no localizado";
    $datos["apellido"]= "Apelllido no localizado";
    $datos["telefono"]= "Telefono no localizado ";
    $datos["correo"]= "Correo no localizado";
    $json['clientes'][] = $datos;

}

mysqli_close($conexion);
echo json_encode($json);
?>
